package org.cap.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	@Autowired
    private final UserRepository userRepository;

    
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
       
    }

   
    public User getUserById(Long id) {
		Optional<User> userOptional = userRepository.findById(id);
        return userOptional.orElse(null);
    }
}
